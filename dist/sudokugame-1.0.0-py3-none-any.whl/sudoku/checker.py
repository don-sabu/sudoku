from . import validtyCheck


def validate(grid):
    return validtyCheck.isValid(grid)
