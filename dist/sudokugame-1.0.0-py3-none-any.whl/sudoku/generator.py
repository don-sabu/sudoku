from . import sudokuGenerator as sg


def generate():
    return sg.Generator.generate_sudoku()
