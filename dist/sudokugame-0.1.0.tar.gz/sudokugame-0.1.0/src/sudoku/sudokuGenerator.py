class Generator:
    @staticmethod
    def generate_sudoku():
        sample_string = "Sudoku Generated!!!"
        return sample_string
