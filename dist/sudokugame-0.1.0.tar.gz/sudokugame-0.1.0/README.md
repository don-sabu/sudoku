# sudoku
repository for maintaining sudoku pypi package
