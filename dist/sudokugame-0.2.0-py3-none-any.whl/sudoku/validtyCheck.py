from . import checker


def is_valid_grid(grid):
    return checker.isValid(grid)
