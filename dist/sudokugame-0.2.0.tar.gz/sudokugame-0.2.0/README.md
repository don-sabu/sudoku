# Sudoku
## sudokugame PyPi Package
####  v0.2.0

```shell
pip install sudokugame
```

Repository for maintaining sudokugame pypi package


Currently, this package is under prerelease development.

Features:
* Checks if a 9x9 sudoku is valid

Features to be added:
* Generate sudoku grid
* Solve given sudoku

